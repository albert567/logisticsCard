﻿summerready = function() {
	$('.um-back').click(function() {
		summer.closeWin();
	});
}
/**
 * 报价
 */
function price() {
	var email = localStorage.getItem("email");
	localStorage.clear();
	localStorage.setItem("email", email);
	summer.openWin({
		id : 'subMenu',
		url : 'html/subMenu.html'
	});
}

/**
 * 历史
 */
function history() {
	summer.openWin({
		id : 'history',
		url : 'html/history.html'
	});
}

/**
 * 帮助
 */
function help() {
	UM.modal("alert", {
		title : window.location.host || "",
		text : "帮助界面还在开发中",
		overlay : true,
		ok : function(data) {

		},
		delay : 300, //Number
		callback : null
	});
}

/**
 * 退出
 */
function logout() {
	localStorage.clear();
	summer.closeWin({
		id : 'menu'
	});
	/*summer.openWin({
		id : 'main',
		url : 'index.html',
	});*/
}

