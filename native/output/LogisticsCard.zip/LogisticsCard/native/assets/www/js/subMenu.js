﻿summerready = function() {
	$('.um-back').click(function() {
		summer.closeWin();
	});
}
function openInfo() {
	UM.modal("alert", {
		title : window.location.host || "",
		text : "请先进行基本信息维护",
		overlay : true,
		ok : function(data) {
			summer.openWin({
				id : 'industry',
				url : 'html/industry.html'
			});
		},
		delay : 300, //Number
		callback : null
	});
}

/**
 * 基本信息维护
 */
function info() {
	summer.openWin({
		id : 'industry',
		url : 'html/industry.html'
	});
}

/**
 * A:地磅计量采集（低配）
 */
function simple() {
	if (localStorage.getItem("baseinfoid") != null) {
		summer.openWin({
			id : 'picDescription1',
			url : 'html/picDescription1.html'
		});
	} else {
		openInfo();
	}

}

/**
 * B:计量一卡通（中配）
 */
function common() {
	if (localStorage.getItem("baseinfoid") != null) {
		summer.openWin({
			id : 'picDescription2',
			url : 'html/picDescription2.html'
		});
	} else {
		openInfo();
	}
}

/**
 * C:智能工厂（高配）
 */
function intel() {
	if (localStorage.getItem("baseinfoid") != null) {
		summer.openWin({
			id : 'picDescription3',
			url : 'html/picDescription3.html'
		});
	} else {
		openInfo();
	}
}

/**
 * D:自定义配置
 */
function custom() {
	if (localStorage.getItem("baseinfoid") != null) {
		summer.openWin({
			id : 'ticket',
			url : 'html/ticket.html'
		});
	} else {
		openInfo();
	}
}

/**
 * 返回主菜单
 */
function back() {
	summer.openWin({
		id : 'menu',
		url : 'html/menu.html'
	});
}

