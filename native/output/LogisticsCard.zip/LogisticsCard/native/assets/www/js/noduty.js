﻿var factories = [];
var index = 1;
var factoryCount = 2;
summerready = function() {
	$('.um-back').click(function() {
		summer.closeWin();
	});

	//报价工厂数
	if (localStorage.getItem("factoryCount") != null) {
		factoryCount = localStorage.getItem("factoryCount");
	}
	//工厂信息数组
	if (localStorage.getItem("factories") != null) {
		factories = JSON.parse(localStorage.getItem("factories"));
		arrToValue();
	}
	updateH3();
}
/**
 * 更新标题
 */
function updateH3() {
	$summer.byId("hh").innerHTML = index + "/" + factoryCount + "工厂信息维护";
}

/**
 * 数组元素赋值给页面
 */
function arrToValue() {
	var factory = factories[index - 1];
	//工厂名称
	$summer.byId("factoryName").value = factory.fac_name;
	//大宗物资进出厂门数
	$summer.byId("itemInOut").value = factory.item_inout;
	//计量衡器数量
	$summer.byId("weightCount").value = factory.wei_count;
	//开单员/班
	$summer.byId("ticketCount").value = factory.tic_count;
	//计量员/班
	$summer.byId("meterCount").value = factory.met_count;
	//是否无人值守计量
	$summer.byId("isNoduty").checked = factory.is_noduty;
	//计量室/班
	$summer.byId("noDutyMonitors").value = factory.nod_monitors;
}

/**
 * 页面赋值给数组元素
 */
function valueToArray() {
	var baseId = localStorage.getItem("baseinfoid");
	var factory = {};
	if (index < factories.length) {
		factory = factories[index - 1];
		//工厂名称
		factory.fac_name = $summer.byId("factoryName").value;
		//大宗物资进出厂门数
		factory.item_inout = $summer.byId("itemInOut").value;
		//计量衡器数量
		factory.wei_count = $summer.byId("weightCount").value;
		//开单员/班
		factory.tic_count = $summer.byId("ticketCount").value;
		//计量员/班
		factory.met_count = $summer.byId("meterCount").value;
		//是否无人值守计量
		factory.is_noduty = $summer.byId("isNoduty").checked;
		//计量室/班
		factory.nod_monitors = $summer.byId("noDutyMonitors").value;

		//更新数据到数据库
		$.post("http://zhangyph-pc/factory/update", {
			fac_name : factory.fac_name,
			item_inout : factory.item_inout,
			wei_count : factory.wei_count,
			tic_count : factory.tic_count,
			met_count : factory.met_count,
			is_noduty : factory.is_noduty,
			nod_monitors : factory.nod_monitors,
			base_id : baseId,
			fa_index : index,
			id : factory.id
		}, function(data) {
			if(data){
				operation();
			}
		});
	} else {
		//工厂名称
		factory.fac_name = $summer.byId("factoryName").value;
		//大宗物资进出厂门数
		factory.item_inout = $summer.byId("itemInOut").value;
		//计量衡器数量
		factory.wei_count = $summer.byId("weightCount").value;
		//开单员/班
		factory.tic_count = $summer.byId("ticketCount").value;
		//计量员/班
		factory.met_count = $summer.byId("meterCount").value;
		//是否无人值守计量
		factory.is_noduty = $summer.byId("isNoduty").checked;
		//计量室/班
		factory.nod_monitors = $summer.byId("noDutyMonitors").value;
		factory.base_id = baseId;

		//保存数据到数据库JSON.stringify(factory)
		$.post("http://zhangyph-pc/factory/save", {
			fac_name : factory.fac_name,
			item_inout : factory.item_inout,
			wei_count : factory.wei_count,
			tic_count : factory.tic_count,
			met_count : factory.met_count,
			is_noduty : factory.is_noduty,
			nod_monitors : factory.nod_monitors,
			base_id : baseId,
			fa_index : index
		}, function(data) {
			if (data != -1) {
				factory.id = data;
				factories.push(factory);
				operation();
			}
		});
	}
}

/**
 * 上一步
 */
function pre() {
	//valueToArray();
	index--;
	if (index < 1) {
		summer.closeWin();
	} else {
		updateH3();
		arrToValue();
	}
}

/**
 * 下一步
 */
function next() {
	valueToArray();
}

function operation(){
	index++;
	if (index <= factoryCount) {
		updateH3();
		if (index <= factories.length) {
			arrToValue();
		} else {
			$summer.byId("isNoduty").checked = true;
		}
	} else {
		index--;
		localStorage.setItem("factories", JSON.stringify(factories));
		summer.openWin({
			id : 'subMenu',
			url : 'html/subMenu.html',
		});
	}
}

