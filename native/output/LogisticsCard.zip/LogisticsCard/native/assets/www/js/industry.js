﻿summerready = function() {
	$('.um-back').click(function() {
		summer.closeWin();
	});
	//行业选择
	if (localStorage.getItem("industry") != null) {
		$summer.byId("industry").value = localStorage.getItem("industry");
	}
	//公司名称
	if (localStorage.getItem("company") != null) {
		$summer.byId("company").value = localStorage.getItem("company");
	}
	//销售分公司
	if (localStorage.getItem("saleCompany") != null) {
		$summer.byId("saleCompany").value = localStorage.getItem("saleCompany");
	}
	//销售顾问
	if (localStorage.getItem("saleAdviser") != null) {
		$summer.byId("saleAdviser").value = localStorage.getItem("saleAdviser");
	}
	//软件折扣
	if (localStorage.getItem("softDiscount") != null) {
		$summer.byId("softDiscount").value = localStorage.getItem("softDiscount");
	}
	//报价工厂数
	if (localStorage.getItem("factoryCount") != null) {
		$summer.byId("factoryCount").value = localStorage.getItem("factoryCount");
	}
	//是否按工厂购买自由报表
	if (localStorage.getItem("isBuyReport") != null) {
		$summer.byId("isBuyReport").checked = localStorage.getItem("isBuyReport") == "true" ? true : false;
	} else {
		$summer.byId("isBuyReport").checked = true;
	}
}
/**
 * 保存信息
 */
function saveInfo() {
	//行业选择
	var industry = $summer.byId("industry");
	//公司名称
	var company = $summer.byId("company");
	//销售分公司
	var saleCompany = $summer.byId("saleCompany");
	//销售顾问
	var saleAdviser = $summer.byId("saleAdviser");
	//软件折扣
	var softDiscount = $summer.byId("softDiscount");
	//报价工厂数
	var factoryCount = $summer.byId("factoryCount");
	//是否按工厂购买自由报表
	var isBuyReport = $summer.byId("isBuyReport");

	localStorage.setItem("industry", industry.value);
	localStorage.setItem("company", company.value);
	localStorage.setItem("saleCompany", saleCompany.value);
	localStorage.setItem("saleAdviser", saleAdviser.value);
	localStorage.setItem("softDiscount", softDiscount.value);
	localStorage.setItem("factoryCount", factoryCount.value);
	localStorage.setItem("isBuyReport", isBuyReport.checked);
	if (localStorage.getItem("baseinfoid") != null) {
		//更新数据到数据库
		$.post("http://zhangyph-pc/baseinfo/update", {
			id : localStorage.getItem("baseinfoid"),
			industry : industry.value,
			company : company.value,
			sale_company : saleCompany.value,
			sale_adviser : saleAdviser.value,
			soft_discount : softDiscount.value,
			factory_count : factoryCount.value,
			is_buy_report : isBuyReport.checked
		}, function(data) {
			//alert("数据保存成功：" + data);
			if (data == "false") {
				alert("数据保存失败：" + data);
			} else {
				summer.openWin({
					id : 'noduty',
					url : 'html/noduty.html',
				});
			}
		});
	} else {
		//保存数据到数据库
		$.post("http://zhangyph-pc/baseinfo/save", {
			email : localStorage.getItem("email"),
			industry : industry.value,
			company : company.value,
			sale_company : saleCompany.value,
			sale_adviser : saleAdviser.value,
			soft_discount : softDiscount.value,
			factory_count : factoryCount.value,
			is_buy_report : isBuyReport.checked
		}, function(data) {
			if (data != -1) {
				localStorage.setItem("baseinfoid", data);
				summer.openWin({
					id : 'noduty',
					url : 'html/noduty.html',
				});
			} else {
				alert("数据保存失败：");
			}
		});
	}

}

/**
 * 上一步
 */
function pre() {
	summer.closeWin();
}

/**
 * 下一步
 */
function next() {
	saveInfo();
}

