﻿summerready = function() {
	
}

//上一步
function pre() {
	summer.closeWin("picDescription");
}

//下一步
function next() {
	
}

